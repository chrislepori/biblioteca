package com.gestion.biblioteca.domain;

public enum Rol {

    ADMIN,
    USER;
}
