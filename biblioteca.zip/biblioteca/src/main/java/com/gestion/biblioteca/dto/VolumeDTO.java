package com.gestion.biblioteca.dto;

import lombok.Data;

@Data
public class VolumeDTO {

    private VolumeInfoDTO volumeInfo;
}
