package com.gestion.biblioteca.service;

import com.gestion.biblioteca.domain.Libro;
import com.gestion.biblioteca.domain.Prestamo;
import com.gestion.biblioteca.domain.Usuario;
import com.gestion.biblioteca.dto.PrestamoDTO;
import com.gestion.biblioteca.dto.PrestamoResponseDTO;
import com.gestion.biblioteca.exception.ApiException;
import com.gestion.biblioteca.exception.MensajeError;
import com.gestion.biblioteca.repository.LibroRepository;
import com.gestion.biblioteca.repository.PrestamoRepository;
import com.gestion.biblioteca.repository.UsuarioRepository;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@AllArgsConstructor
public class PrestamoService {

    private static final int CANT_DIAS = 10;

    private final PrestamoRepository prestamoRepository;
    private final LibroRepository libroRepository;
    private final UsuarioRepository usuarioRepository;
    private final ModelMapper modelMapper;


    public PrestamoResponseDTO crearPrestamo(PrestamoDTO prestamoDTO){
        Libro libro = libroRepository.findById(prestamoDTO.getLibroId())
                .orElseThrow(() -> new ApiException(MensajeError.LIBRO_NOT_FOUND));
        if(!libro.isAvailable()){
            throw new ApiException(MensajeError.LIBRO_NOT_AVAILABLE);

        }

        Usuario usuario = usuarioRepository.findById(prestamoDTO.getUsuarioId())
                .orElseThrow(()-> new ApiException(MensajeError.USUARIO_NOT_FOUND));

        LocalDate fechaActual = LocalDate.now();
        LocalDate fechaDevolucion = fechaActual.plusDays(CANT_DIAS);

        Prestamo prestamo = Prestamo.builder()
                .libro(libro)
                .usuario(usuario)
                .fechaPrestamo(fechaActual)
                .fechaDevolucion(fechaDevolucion)
                .build();

        libro.descontarCantidad();
        prestamoRepository.save(prestamo);

        return modelMapper.map(prestamo, PrestamoResponseDTO.class);


    }

    public void deletePrestamo(Long id){
        Prestamo prestamo = prestamoRepository.findById(id)
                .orElseThrow(() -> new ApiException(MensajeError.PRESTAMO_NOT_FOUND));
        Libro libro = prestamo.getLibro();
        prestamoRepository.delete(prestamo);
        libro.aumentarCantidad();


    }

    public PrestamoResponseDTO findById(Long id){
        Prestamo prestamo = prestamoRepository.findById(id)
                .orElseThrow(() -> new ApiException(MensajeError.PRESTAMO_NOT_FOUND));
        return modelMapper.map(prestamo, PrestamoResponseDTO.class);

    }




}
